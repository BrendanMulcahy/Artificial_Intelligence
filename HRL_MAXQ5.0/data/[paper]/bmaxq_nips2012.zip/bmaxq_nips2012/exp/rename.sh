mv bayesTaxi1.pdf Taxib.pdf
mv bayesTaxi2.pdf Taxinb.pdf
mv bayesWargus1.pdf Wargus3322b.pdf
mv bayesWargus2.pdf Wargus3322nb.pdf
mv prTaxi1.pdf Taxi_Modified_b.pdf
mv prTaxi2.pdf Taxi_Modified_nb.pdf
mv prHallway1.pdf Hallwayb.pdf
mv prHallway2.pdf Hallwaynb.pdf